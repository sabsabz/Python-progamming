AI CHATBOT

This is an AI chatbot program created by AwesomeGaming597 and posted on Replit by the user 'ConnorAmico'. The chatbot can answer questions and learn from user inputs. The chatbot can also do some basic Python, lua, C, C#, C++, HTML, CSS, and JS coding.

REQUIREMENTS

This program only requires the files that come with this This AI chatbot is being used and run off of replit, so no dependancies are needed.

USAGE

To use this chatbot, simply run the chatbot in the console. The chatbot will prompt the user for input and will respond with appropriate answers. If the chatbot does not know the answer to a question, it will ask the user to provide an answer, which will be saved for future use. There is also a learning feature implimented which means if the AI does not know an answer, you can provide one and the AI will now know it and learn it. However, with the learning feature, I am aware that some poeple may teach my bot some incorrect information and ruin it fro everyone else, as when one person decides to teach it something, the AI learns it, meaning it is now in its brain as knolage. So, as a fix to this problem, I hav decided to make all things the bot is taught temperary and clietn sided, meaning the bot's knolage of what you taught it dissapears after you stop the bot, but it is not lost as all data you guys teach the bot will go into the 'Data_Request.json' file for me to review and possibly put that into the next update.

FILES

trainer.json: A JSON file containing questions and answers used to train the chatbot, so it can better assist you.

FUNCTIONALITY

The chatbot works by comparing user input to questions and answers it learns from the trainer.json file. If the user input exactly matches a question, the chatbot will respond with the corresponding answer. If the user input contains a word that matches a question, the chatbot will respond with the corresponding answer it has learned. If the user input does not match any questions, the chatbot will ask the user to provide an answer, which will be saved for future use. The chatbot also has some basic context awareness, and can ask for clarification if a user input contains a 'why' or 'how' question.

UPCOMING UPDATES

We are currently working on adding the following features to the chatbot:

Better and updated Natural Language Processing (NLP) to improve the chatbot's ability to understand and respond to user input

Machine Learning to improve the chatbot's ability to learn and adapt to new information

Integration with external APIs to provide more accurate and up-to-date information Stay tuned for updates and new releases!

CONTRIBUTION

This code is free to use and modify under the MIT license. If you would like to contribute to the project, please fork the repository and modify the code as you please, or contact me with your suggestions on discord. Discord: millah#7153